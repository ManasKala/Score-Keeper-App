package com.example.abnd_p2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    int team1score=0;
    int team2score=0;
    int team1foul=0;
    int team2foul=0;


    public void setTeam1score(View view) {
        if (view==findViewById(R.id.team1scorebutton1))
        team1score++;
        else
        team1score= team1score+3;
        TextView team1ScoreTextView= (TextView) findViewById(R.id.team1Score);
        team1ScoreTextView.setText(""+team1score);
    }

    public void setTeam2score(View view) {
        if (view==findViewById(R.id.team2scorebutton1))
            team2score++;
        else
            team2score= team2score+3;
        TextView team2ScoreTextView= (TextView) findViewById(R.id.team2Score);
        team2ScoreTextView.setText(""+team2score);

    }

    public void setTeam1foul(View view) {
        team1foul++;
       // team1score--;
        TextView team1foulTextView= (TextView) findViewById(R.id.team1Foul);
        team1foulTextView.setText(""+team1foul);
       // TextView team1ScoreTextView= (TextView) findViewById(R.id.team1Score);
        //team1ScoreTextView.setText(""+team1score);

    }

    public void setTeam2foul(View view) {
        team2foul++;
       // team2score--;
        TextView team2foulTextView= (TextView) findViewById(R.id.team2Foul);
        team2foulTextView.setText(""+team2foul);
        //TextView team2ScoreTextView= (TextView) findViewById(R.id.team2Score);
        //team2ScoreTextView.setText(""+team2score);
    }

    public void resetScore(View view){
        team1score=team2score=team1foul=team2foul=0;
        TextView team1foulTextView= (TextView) findViewById(R.id.team1Foul);
        team1foulTextView.setText(""+team1foul);
        TextView team1ScoreTextView= (TextView) findViewById(R.id.team1Score);
        team1ScoreTextView.setText(""+team1score);
        TextView team2foulTextView= (TextView) findViewById(R.id.team2Foul);
        team2foulTextView.setText(""+team2foul);
        TextView team2ScoreTextView= (TextView) findViewById(R.id.team2Score);
        team2ScoreTextView.setText(""+team2score);

    }

}
